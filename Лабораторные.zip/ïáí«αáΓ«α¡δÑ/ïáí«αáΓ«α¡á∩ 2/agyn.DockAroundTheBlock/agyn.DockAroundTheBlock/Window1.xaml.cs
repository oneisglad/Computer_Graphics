﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace agyn.DockAroundTheBlock
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class DockAroundTheBlock : Window
    {
        public DockAroundTheBlock()
        {
            InitializeComponent();
            Title = "Dock Around the Block";
            DockPanel dock = new DockPanel();
            Content = dock;
            for (int i = 0; i < 17; i++)
            {
                Button btn = new Button();
                btn.Content = "Button No. " + (i + 1);
                dock.Children.Add(btn);
                btn.SetValue(DockPanel.DockProperty, (Dock)(i % 4));
            }
        }
    }
}
