﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;

namespace agyn.MeetTheDockers
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class MeetTheDockers : Window
    {
        public MeetTheDockers()
        {
            InitializeComponent();
            Title = "Meet the Dockers";
            DockPanel dock = new DockPanel();
            Content = dock;

            Menu menu = new Menu();
            MenuItem item = new MenuItem();
            item.Header = "Menu";
            menu.Items.Add(item);

            DockPanel.SetDock(menu, Dock.Top);
            dock.Children.Add(menu);

            ToolBar tool = new ToolBar();
            tool.Header = "Toolbar";

            DockPanel.SetDock(tool, Dock.Top);
            dock.Children.Add(tool);

            StatusBar status = new StatusBar();
            StatusBarItem statitem = new StatusBarItem();
            statitem.Content = "Status";
            status.Items.Add(statitem);

            DockPanel.SetDock(status, Dock.Bottom);
            dock.Children.Add(status);

            ListBox lstbox = new ListBox();
            lstbox.Items.Add("List Box Item");

            DockPanel.SetDock(lstbox, Dock.Left);
            dock.Children.Add(lstbox);

            TextBox txtbox = new TextBox();
            txtbox.AcceptsReturn = true;

            dock.Children.Add(txtbox);
            txtbox.Focus();

            Grid grid = new Grid();
            grid.ShowGridLines = true;
            new GridLength(100, GridUnitType.Pixel);

            RowDefinition rowdef = new RowDefinition();
            rowdef.Height = GridLength.Auto;
            grid.RowDefinitions.Add(rowdef);

            rowdef = new RowDefinition();
            rowdef.Height = new GridLength(33, GridUnitType.Star);
            grid.RowDefinitions.Add(rowdef);

            rowdef = new RowDefinition();
            rowdef.Height = new GridLength(150);
            grid.RowDefinitions.Add(rowdef);

            rowdef = new RowDefinition();
            rowdef.Height = new GridLength(67, GridUnitType.Star);
            grid.RowDefinitions.Add(rowdef);
        }
    }
}
