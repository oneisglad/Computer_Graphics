﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using agyn.PaintOnCanvasCln;

namespace agyn.DrawCircles
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class DrawCircles : Window
    {
        CanvasClone canv;
        bool isDrawing;
        Ellipse elips;
        Point ptCenter;

        bool isDragging;
        FrameworkElement elDragging;
        Point ptMouseStart, ptElementStart;

        public DrawCircles()
        {
            InitializeComponent();
            Title = "Draw Circles";
            Content = canv = new CanvasClone();
        }

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);

            if (isDragging)
                return;

            ptCenter = e.GetPosition(canv);
            elips = new Ellipse();
            elips.Stroke = SystemColors.WindowTextBrush;
            elips.StrokeThickness = 1;
            elips.Width = 0;
            elips.Height = 0;
            canv.Children.Add(elips);
            CanvasClone.SetLeft(elips, ptCenter.X);
            CanvasClone.SetTop(elips, ptCenter.Y);

            CaptureMouse();
            isDrawing = true;
        }

        protected override void OnMouseRightButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseRightButtonDown(e);

            if (isDrawing)
                return;

            ptMouseStart = e.GetPosition(canv);
            elDragging = canv.InputHitTest(ptMouseStart) as FrameworkElement;
            if (elDragging != null)
            {
                ptElementStart = new Point(CanvasClone.GetLeft(elDragging),
                CanvasClone.GetTop(elDragging));
                isDragging = true;
            }
        }

        protected override void OnMouseDown(MouseButtonEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.ChangedButton == MouseButton.Middle)
            {
                Shape shape = canv.InputHitTest(e.GetPosition(canv)) as Shape;
                if (shape != null)
                    shape.Fill = (shape.Fill == Brushes.Red ?
                        Brushes.Transparent : Brushes.Red);
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            Point ptMouse = e.GetPosition(canv); ;

            if (isDrawing)
            {
                double dRadius = Math.Sqrt(Math.Pow(ptCenter.X - ptMouse.X, 2) +
                    Math.Pow(ptCenter.Y - ptMouse.Y, 2));
                CanvasClone.SetLeft(elips, ptCenter.X - dRadius);
                CanvasClone.SetTop(elips, ptCenter.Y - dRadius);
                elips.Width = 2 * dRadius;
                elips.Height = 2 * dRadius;
            }
            else if (isDragging)
            {
                CanvasClone.SetLeft(elDragging, ptElementStart.X + ptMouse.X - ptMouseStart.X);
                CanvasClone.SetTop(elDragging, ptElementStart.Y + ptMouse.Y - ptMouseStart.Y);
            }
        }

        protected override void OnMouseUp(MouseButtonEventArgs e)
        {
            base.OnMouseUp(e);
            if (isDrawing && e.ChangedButton == MouseButton.Left)
            {
                elips.Stroke = Brushes.Blue;
                elips.StrokeThickness = Math.Min(24, elips.Width / 2);
                elips.Fill = Brushes.Red;
                isDrawing = false;
                ReleaseMouseCapture();
            }
            else if (isDragging && e.ChangedButton == MouseButton.Right)
            {
                isDragging = false;
            }
        }

        protected override void OnTextInput(TextCompositionEventArgs e)
        {
            base.OnTextInput(e);
            if(e.Text.IndexOf('\x1B') != -1)
            {
                if (isDrawing)
                    ReleaseMouseCapture();
                else if (isDragging)
                {
                    CanvasClone.SetLeft(elDragging, ptElementStart.X);
                    CanvasClone.SetTop(elDragging, ptElementStart.Y);
                    isDragging = false;
                }
            }
        }

        protected override void  OnLostMouseCapture(MouseEventArgs e)
        {
 	        base.OnLostMouseCapture(e);
            if (isDrawing)
            {
                canv.Children.Remove(elips);
                isDrawing = false;
            }
        }
    }
}
