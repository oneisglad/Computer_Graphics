﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Globalization;
using System.Printing;

namespace agyn.PrintWithMargins
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        PrintQueue prnqueue;
        PrintTicket prntkt;
        Thickness marginPage = new Thickness(96);

        public Window1()
        {
            InitializeComponent();
            Title = "Print with Margins";
            FontSize = 24;

            StackPanel stack = new StackPanel();
            Content = stack;

            Button btn = new Button();
            btn.Content = "Page Set_up...";
            btn.HorizontalAlignment = HorizontalAlignment.Center;
            btn.Margin = new Thickness(24);
            btn.Click += SetupOnClick;
            stack.Children.Add(btn);

            btn = new Button();
            btn.Content = "_Print...";
            btn.HorizontalAlignment = HorizontalAlignment.Center;
            btn.Margin = new Thickness(24);
            btn.Click += PrintOnClick;
            stack.Children.Add(btn);
        }

        void SetupOnClick(object sender, RoutedEventArgs e)
        {
            PageMarginsDialog dlg = new PageMarginsDialog();
            dlg.Owner = this;
            dlg.PageMargins = marginPage;
            if (dlg.ShowDialog().GetValueOrDefault())
            {
                marginPage = dlg.PageMargins;
            }
        }

        void PrintOnClick(object sender, RoutedEventArgs e)
        {
            PrintDialog dlg = new PrintDialog();

            if (prnqueue != null)
                dlg.PrintQueue = prnqueue;
            if (prntkt != null)
                dlg.PrintTicket = prntkt;
            if (dlg.ShowDialog().GetValueOrDefault())
            {
                prnqueue = dlg.PrintQueue;
                prntkt = dlg.PrintTicket;

                DrawingVisual vis = new DrawingVisual();
                DrawingContext dc = vis.RenderOpen();
                Pen pn = new Pen(Brushes.Black, 1);

                Rect rectPage = new Rect(marginPage.Left, marginPage.Top, dlg.PrintableAreaWidth - (marginPage.Left +
                    marginPage.Right), dlg.PrintableAreaHeight - (marginPage.Top + marginPage.Bottom));

                dc.DrawRectangle(null, pn, rectPage);

                FormattedText formtxt = new FormattedText(String.Format("Hello, Printer! {0} x {1}",
                    dlg.PrintableAreaWidth / 96, dlg.PrintableAreaHeight / 96),
                    CultureInfo.CurrentCulture, FlowDirection.LeftToRight, new Typeface(new FontFamily("Times New Roman"),
                        FontStyles.Italic, FontWeights.Normal, FontStretches.Normal), 48, Brushes.Black);

                Size sizeText = new Size(formtxt.Width, formtxt.Height);

                Point ptTexr = new Point(rectPage.Left + (rectPage.Width - formtxt.Width) / 2,
                    rectPage.Top + (rectPage.Height - formtxt.Height) / 2);

                dc.DrawText(formtxt, ptTexr);
                dc.DrawRectangle(null, pn, new Rect(ptTexr, sizeText));
                dc.Close();

                dlg.PrintVisual(vis, Title);
            }
        }
    }
}
