﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace agyn.PrintEllipse
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
            Title = "Print Ellipse";
            FontSize = 24;

            StackPanel stack = new StackPanel();
            Content = stack;
            Button btn = new Button();
            btn.Content = "_Print...";
            btn.HorizontalAlignment = HorizontalAlignment.Center;
            btn.Margin = new Thickness(24);
            btn.Click += PrintOnClick;
            stack.Children.Add(btn);
        }

        void PrintOnClick(object sender, RoutedEventArgs e)
        {
            PrintDialog dlg = new PrintDialog();
            if ((bool)dlg.ShowDialog().GetValueOrDefault())
            {
                DrawingVisual vis = new DrawingVisual();
                DrawingContext dc = vis.RenderOpen();

                dc.DrawEllipse(Brushes.LightGray, new Pen(Brushes.Black, 3),
                    new Point(dlg.PrintableAreaWidth/2, dlg.PrintableAreaHeight/2),
                    dlg.PrintableAreaWidth/2, dlg.PrintableAreaHeight/2);

                dc.Close();
                dlg.PrintVisual(vis, "My first print job");
            }
        }
    }
}
