﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace agyn.CreateFullColorBitmap
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class CreateFullColorBitmap : Window
    {
        public CreateFullColorBitmap()
        {
            InitializeComponent();

            int[] array = new int[256 * 256];

            for (int x = 0; x < 256; x++)
                for (int y = 0; y < 256; y++)
                {
                    int b = x;
                    int g = 0;
                    int r = y;
                    array[256 * y + x] = b | (g << 8) | (r << 16);
                }
            BitmapSource bitmap = BitmapSource.Create(256, 256, 96, 96, PixelFormats.Bgr32,
                null, array, 256 * 4);

            Image img = new Image();
            img.Source = bitmap;

            Content = img;
        }
    }
}
