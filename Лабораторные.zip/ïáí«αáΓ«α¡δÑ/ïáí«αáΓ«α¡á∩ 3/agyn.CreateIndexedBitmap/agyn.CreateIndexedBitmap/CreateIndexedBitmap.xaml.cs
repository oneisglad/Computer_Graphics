﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace agyn.CreateIndexedBitmap
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class CreateIndexedBitmap : Window
    {
        public CreateIndexedBitmap()
        {
            InitializeComponent();

            List<Color> colors = new List<Color>();
            for (int r = 0; r < 256; r += 17)
                for (int b = 0; b < 256; b += 17)
                    colors.Add(Color.FromRgb((byte)r, 0, (byte)b));

            BitmapPalette palette = new BitmapPalette(colors);
            byte[] array = new byte[256 * 256];

            for (int x = 0; x < 256; x++)
                for (int y = 0; y < 256; y++)
                    array[256 * y + x] = (byte)(((int)Math.Round(y / 17.0) << 4) |
                        (int)Math.Round(x / 17.0));

            BitmapSource bitmap = BitmapSource.Create(256, 256, 96, 96, PixelFormats.Indexed8,
                palette, array, 256);

            Image img = new Image();
            img.Source = bitmap;

            Content = img;
        }
    }
}
