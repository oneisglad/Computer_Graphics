﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace agyn.DrawGraphicsOnBitmap
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class DrawGraphicsOnBitmap : Window
    {
        public DrawGraphicsOnBitmap()
        {
            InitializeComponent();
            Title = "Draw Graphics on Bitmap";

            Background = Brushes.Khaki;
            RenderTargetBitmap renderbitmap = new RenderTargetBitmap(100, 100, 96, 96, PixelFormats.Default);

            DrawingVisual drawvis = new DrawingVisual();
            DrawingContext dc = drawvis.RenderOpen();
            dc.DrawRoundedRectangle(Brushes.Blue, new Pen(Brushes.Red, 10),
                new Rect(25, 25, 50, 50), 10, 10);
            dc.Close();

            renderbitmap.Render(drawvis);

            Image img = new Image();
            img.Source = renderbitmap;
            //img.Stretch = Stretch.None;
            Content = img;
        }
    }
}
