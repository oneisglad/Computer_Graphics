﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace agyn.ClickTheButton
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class ClickTheButton : Window
    {
        public ClickTheButton()
        {
            InitializeComponent();
            Title = "Click the Button";

            Button btn = new Button();
            btn.Content = "_Click me, please!";
            btn.Click += ButtonOnClick;
            btn.Margin = new Thickness(96);
            btn.HorizontalContentAlignment = HorizontalAlignment.Left;
            btn.VerticalContentAlignment = VerticalAlignment.Bottom;
            btn.Padding = new Thickness(96);
            btn.HorizontalAlignment = HorizontalAlignment.Center;
            btn.VerticalAlignment = VerticalAlignment.Center;
            btn.FontSize = 48;
            btn.FontFamily = new FontFamily("Times New Roman");
            btn.Background = Brushes.AliceBlue;
            btn.Foreground = Brushes.DarkSalmon;
            btn.BorderBrush = Brushes.Magenta;
            Content = btn;
        }

        void ButtonOnClick(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("The button has been clicked and all is well.", Title);
        }
    }
}
