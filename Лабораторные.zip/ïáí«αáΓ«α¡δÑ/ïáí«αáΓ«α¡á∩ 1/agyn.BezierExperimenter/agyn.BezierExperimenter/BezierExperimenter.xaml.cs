﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace agyn.BezierExperimenter
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class BezierExperimenter : Window
    {
        public BezierExperimenter()
        {
            InitializeComponent();
            canvas.SizeChanged += CanvasOnSizeChanged;
        }

        protected virtual void CanvasOnSizeChanged(object dender, SizeChangedEventArgs e)
        {
            ptStart.Center = new Point(e.NewSize.Width / 4, e.NewSize.Height / 2);
            ptCtrl1.Center = new Point(e.NewSize.Width / 2, e.NewSize.Height / 4);
            ptCtrl2.Center = new Point(e.NewSize.Width / 2, 3 * e.NewSize.Height / 4);
            ptCtrl1.Center = new Point(3 * e.NewSize.Width / 4, e.NewSize.Height / 2);

        }

        protected override void OnMouseDown(MouseButtonEventArgs e)
        {
            base.OnMouseDown(e);
            Point pt = e.GetPosition(canvas);
            if (e.ChangedButton == MouseButton.Left)
                ptCtrl1.Center = pt;
            if (e.ChangedButton == MouseButton.Right)
                ptCtrl2.Center = pt;
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            Point pt = e.GetPosition(canvas);
            if (e.LeftButton == MouseButtonState.Pressed)
                ptCtrl1.Center = pt;
            if (e.RightButton == MouseButtonState.Pressed)
                ptCtrl2.Center = pt;
        }
    }
}
