using System;
using System.Windows;
using System.Data;
using System.Xml;
using System.Configuration;

namespace LayoutPanels
{
    /// <summary>
    /// Interaction logic for MyApp.xaml
    /// </summary>

    public partial class MyApp : Application
    {

    }
}